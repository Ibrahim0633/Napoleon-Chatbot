const { translateToEnglish } = require("./translator");

async function main() {
    // Example Bulgarian message. Replace this with another test message if needed.
    const message = "Здравейте, имам болки в гърдите.";

    try {
        const result = await translateToEnglish(message);

        console.log("-----------------------------");
        console.log("CHATBOT TRANSLATION TEST");
        console.log("-----------------------------");
        console.log("Original message:", result.originalMessage);
        console.log("Detected language:", result.detectedLanguage);
        console.log("English translation:", result.translatedMessage);
        console.log("-----------------------------");
    } catch (error) {
        console.error("Translation test failed:", error.message);
        console.error(
            "Check that LibreTranslate is running at http://localhost:5000."
        );
        process.exitCode = 1;
    }
}

main();
