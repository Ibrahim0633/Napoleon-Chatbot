const TRANSLATE_URL = "http://localhost:5000/translate";

/**
 * Translate a patient's message into English using a locally hosted
 * LibreTranslate server.
 *
 * Requires Node.js 18+ (built-in fetch) and LibreTranslate running locally.
 */
async function translateToEnglish(message) {
    if (typeof message !== "string" || !message.trim()) {
        throw new Error("Please enter a non-empty message.");
    }

    const response = await fetch(TRANSLATE_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            q: message,
            source: "auto",
            target: "en",
            format: "text"
        })
    });

    if (!response.ok) {
        const details = await response.text().catch(() => "");
        throw new Error(
            `Translation service returned ${response.status}. ${details}`
        );
    }

    const data = await response.json();

    if (typeof data.translatedText !== "string" || !data.translatedText.trim()) {
        throw new Error("The translation service did not return a translation.");
    }

    return {
        originalMessage: message,
        translatedMessage: data.translatedText,
        detectedLanguage: data.detectedLanguage?.language ?? "unknown"
    };
}

module.exports = { translateToEnglish };
